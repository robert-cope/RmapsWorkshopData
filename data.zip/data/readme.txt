Frogwatch data are from the following paper:

Westgate, M. J., Scheele, B. C., Ikin, K., Hoefer, A. M., Beaty, R. M., Evans, M., ... & Driscoll, D. A. (2015). Citizen science program shows urban areas have lower occurrence of frog species, but not accelerated declines. *PloS one*, 10(11), e0140973.

https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0140973
https://datadryad.org/stash/dataset/doi:10.5061/dryad.75s51

Thanks to the authors for making these data open.

-----

ABS SA2 data from the Australian Bureau of Statistics. These data are the SA2 boundaries available online, trimmed to only include regions in the ACT. The data were obtained here:

https://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/1270.0.55.001July%202016?OpenDocument

-----

Average temperature data for July for (some of) Canberra was obtained from worldclim
https://www.worldclim.org/data/worldclim21.html

Fick, S.E. and R.J. Hijmans, 2017. WorldClim 2: new 1km spatial resolution climate surfaces for global land areas. International Journal of Climatology 37 (12): 4302-4315.

The tavg 30s raster was downloaded and trimmed to the extent used here.






